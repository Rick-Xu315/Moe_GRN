# Getting Started

Contextualized.ML is a statistical machine learning toolbox for estimating context-specific models.

Let's get started!