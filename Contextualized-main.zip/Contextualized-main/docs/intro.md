# Contextualized.ML

Welcome! Contextualized.ML is an ML toolbox for estimating models with context-specific parameters.

```{tableofcontents}
```
