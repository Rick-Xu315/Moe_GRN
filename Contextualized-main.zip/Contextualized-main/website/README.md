# Contextualized.ML websites
Holding the website files for Contextualized.ML

## Publishing Process

1. Remake docs:
    `cd ../`
    `jupyter-book build docs`
2. Pull `docs/_build/html` in live repo.