import unittest
from contextualized.regression.tests import *
from contextualized.dags.tests import *
from contextualized.easy.tests.test_regressor import *
from contextualized.easy.tests.test_classifier import *

if __name__ == '__main__':
    unittest.main()
