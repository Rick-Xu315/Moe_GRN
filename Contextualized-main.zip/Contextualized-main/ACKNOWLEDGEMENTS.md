Thank you to everyone here for your impactful contributions!

- Maruan Al-Shedivat
- Bryon Aragam
- Rich Caruana
- Avinava Dubey
- Manolis Kellis
- Eric Xing